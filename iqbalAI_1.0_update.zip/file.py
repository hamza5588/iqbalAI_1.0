# from langchain_openai import ChatOpenAI

# model=ChatOpenAI(api_key="")
# responce=model.invoke("hi")
# print(responce)
