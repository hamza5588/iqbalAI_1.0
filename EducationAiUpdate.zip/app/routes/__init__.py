from .auth import bp as auth_bp
from .chat import bp as chat_bp
from .files import bp as files_bp
