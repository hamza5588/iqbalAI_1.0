import os
from groq import Groq
from langchain_nomic import NomicEmbeddings
from langchain_community.vectorstores import FAISS
from typing import Optional, List, Dict, Any
import sqlite3
from datetime import datetime
import logging
from app.utils.db import get_db
import pickle
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import httpx
from httpx import Timeout
from threading import Lock
import time
from collections import deque
import random
import re
import json

logger = logging.getLogger(__name__)
# Add this to your app's initialization code (before any Groq clients are created)
from groq import Groq
from functools import wraps

# model.py
from groq import Groq
from functools import wraps

original_init = Groq.__init__

@wraps(original_init)
def patched_init(self, *args, **kwargs):
    # Log the kwargs before removing 'proxies'
    logger.debug(f"Initializing Groq client with kwargs: {kwargs}")
    if 'proxies' in kwargs:
        logger.debug("Removing 'proxies' from kwargs before initializing Groq client")
        kwargs.pop('proxies')
    return original_init(self, *args, **kwargs)

Groq.__init__ = patched_init
logger.debug("Groq client patched to remove 'proxies' parameter")
class UserModel:
    """User model for handling user-related database operations"""
    
    def __init__(self, user_id: Optional[int] = None):
        self.user_id = user_id
    
    @staticmethod
    def create_user(username: str, useremail: str, password: str, 
                   class_standard: str, medium: str, groq_api_key: str) -> int:
        """Create a new user in the database"""
        try:
            db = get_db()
            cursor = db.execute(
                'INSERT INTO users (username, useremail, password, class_standard, medium, groq_api_key) '
                'VALUES (?, ?, ?, ?, ?, ?)',
                (username, useremail, password, class_standard, medium, groq_api_key)
            )
            db.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError as e:
            logger.error(f"User creation failed - integrity error: {str(e)}")
            raise ValueError("Username or email already exists")
        except Exception as e:
            logger.error(f"User creation failed: {str(e)}")
            raise

    @staticmethod
    def get_user_by_email(useremail: str) -> Dict[str, Any]:
        """Retrieve user details by email"""
        try:
            db = get_db()
            user = db.execute(
                'SELECT * FROM users WHERE useremail = ?', 
                (useremail,)
            ).fetchone()
            return dict(user) if user else None
        except Exception as e:
            logger.error(f"Error retrieving user by email: {str(e)}")
            raise

    def update_api_key(self, new_api_key: str) -> bool:
        """Update user's Groq API key"""
        try:
            if not self.user_id:
                raise ValueError("User ID is required")
            
            db = get_db()
            db.execute(
                'UPDATE users SET groq_api_key = ? WHERE id = ?',
                (new_api_key, self.user_id)
            )
            db.commit()
            return True
        except Exception as e:
            logger.error(f"API key update failed: {str(e)}")
            raise

# app/models/models.py (ChatModel part)
from langchain_groq import ChatGroq
from typing import Optional, List, Dict, Any
import logging
import time

logger = logging.getLogger(__name__)

class TokenBucket:
    """Token bucket rate limiter implementation"""
    def __init__(self, rate: float, capacity: int):
        self.rate = rate  # tokens per second
        self.capacity = capacity  # maximum tokens
        self.tokens = capacity  # current tokens
        self.last_update = time.time()
        self.lock = Lock()
        self.request_history = deque(maxlen=100)  # Track last 100 requests
        self.error_count = 0
        self.last_error_time = 0
        self.daily_limit_hit = False
        self.daily_limit_reset_time = 0

    def acquire(self, tokens: int = 1) -> bool:
        """Acquire tokens from the bucket"""
        with self.lock:
            now = time.time()
            
            # Check if we're in daily limit cooldown
            if self.daily_limit_hit and now < self.daily_limit_reset_time:
                return False
            
            # Add new tokens based on time passed
            time_passed = now - self.last_update
            new_tokens = time_passed * self.rate
            
            # If we've had recent errors, reduce the rate by 25% instead of 50%
            if self.error_count > 0 and now - self.last_error_time < 60:
                new_tokens *= 0.75  # Reduce rate by 25% after errors
            
            self.tokens = min(self.capacity, self.tokens + new_tokens)
            self.last_update = now

            if self.tokens >= tokens:
                self.tokens -= tokens
                self.request_history.append(now)
                return True
            return False

    def record_error(self, error_data: Optional[Dict] = None):
        """Record an error occurrence"""
        with self.lock:
            self.error_count += 1
            self.last_error_time = time.time()
            
            # Handle daily limit error
            if error_data and isinstance(error_data, dict):
                if error_data.get('code') == 'rate_limit_exceeded' and error_data.get('type') == 'tokens':
                    self.daily_limit_hit = True
                    # Parse the reset time from the error message
                    try:
                        reset_time_str = error_data.get('message', '').split('try again in ')[1].split('.')[0]
                        minutes, seconds = map(int, reset_time_str.split('m'))
                        self.daily_limit_reset_time = time.time() + (minutes * 60) + seconds
                    except:
                        # Default to 1 hour if parsing fails
                        self.daily_limit_reset_time = time.time() + 3600
            
            # Clear error count after 5 minutes
            if time.time() - self.last_error_time > 300:
                self.error_count = 0
                self.daily_limit_hit = False

class ChatModel:
    """Model for handling chat-related operations"""
    
    def __init__(self, api_key: str, user_id: int = None):
        self.api_key = api_key
        self.user_id = user_id
        self._chat_model = None
        self.vector_store = VectorStoreModel(user_id=user_id)
        # Optimize timeout settings for faster responses
        self.timeout = Timeout(
            timeout=15.0,  # Reduced from 20.0
            connect=3.0,   # Reduced from 5.0
            read=10.0,     # Reduced from 15.0
            write=3.0      # Reduced from 5.0
        )
        # Increase rate limiter capacity and rate
        self.rate_limiter = TokenBucket(rate=10/60, capacity=10)  # Increased from 5/60 and capacity 5
        self.last_request_time = 0
        self.min_request_interval = 0.5  # Reduced from 1.0 seconds
        self.daily_limit = 100000  # Daily token limit
        self.used_tokens = 0  # Track used tokens
        self.requested_tokens = 0  # Track requested tokens
    
    @property
    def chat_model(self):
        """Lazy initialization of chat model"""
        if not self._chat_model:
            try:
                self._chat_model = ChatGroq(
                    api_key=self.api_key,
                    model_name="llama-3.3-70b-versatile",
                    timeout=self.timeout,
                    max_retries=3,
                  

                )
            except Exception as e:
                logger.error(f"Failed to initialize chat model: {str(e)}")
                raise
        return self._chat_model

    def _wait_for_token(self):
        """Wait for a token to become available with jitter"""
        while not self.rate_limiter.acquire():
            # Add random jitter to prevent thundering herd
            jitter = random.uniform(0.1, 0.5)
            time.sleep(jitter)
            
            # Ensure minimum interval between requests
            now = time.time()
            if now - self.last_request_time < self.min_request_interval:
                time.sleep(self.min_request_interval - (now - self.last_request_time))

    def _handle_error(self, error: Exception) -> Dict:
        """Handle errors and update rate limiter state"""
        error_info = {
            'error': str(error),
            'retry_after': None,
            'is_daily_limit': False
        }
        
        if isinstance(error, httpx.HTTPStatusError):
            try:
                error_data = error.response.json()
                self.rate_limiter.record_error(error_data.get('error', {}))
                
                if error.response.status_code == 429:
                    if error_data.get('error', {}).get('type') == 'tokens':
                        error_info['is_daily_limit'] = True
                        error_info['retry_after'] = self.rate_limiter.daily_limit_reset_time - time.time()
                        logger.warning(f"Daily token limit reached. Reset in {error_info['retry_after']} seconds")
                    else:
                        logger.warning("Rate limit hit, increasing delay")
                        time.sleep(10)
                elif error.response.status_code >= 500:
                    logger.warning("Server error, adding delay")
                    time.sleep(5)
            except:
                logger.error("Error parsing error response")
        
        elif isinstance(error, httpx.TimeoutException):
            logger.warning("Request timeout, adding delay")
            time.sleep(3)
        
        return error_info

    @retry(
        stop=stop_after_attempt(3),  # Increased from 2
        wait=wait_exponential(multiplier=0.5, min=1, max=5),  # More aggressive retry
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.RequestError, httpx.TimeoutException)),
        reraise=True
    )
    def generate_response(self, input_text: str, 
                         system_prompt: Optional[str] = None, 
                         chat_history: Optional[List[Dict]] = None) -> str:
        """Generate a response using the chat model with vector store context"""
        try:
            # Wait for rate limiter token with reduced jitter
            self._wait_for_token()
            self.last_request_time = time.time()
            
            # Initialize messages list
            messages = []
            
            # Add system prompt if provided
            if system_prompt:
                messages.append({
                    "role": "system",
                    "content": system_prompt
                })
            
            # Add formatted chat history if provided
            if chat_history:
                # Ensure chat history is properly formatted
                for msg in chat_history:
                    if 'role' in msg and 'content' in msg:
                        messages.append({
                            "role": msg['role'],
                            "content": msg['content']
                        })
            
            # Add current user message
            messages.append({
                "role": "user",
                "content": input_text
            })
            
            # Log the messages being sent to the model for debugging
            logger.debug(f"Sending messages to model: {messages}")
            
            # Generate response with timeout
            try:
                response = self.chat_model.invoke(messages)
                
                # Update token usage
                if hasattr(response, 'usage'):
                    self.used_tokens += response.usage.get('total_tokens', 0)
                    self.requested_tokens += response.usage.get('prompt_tokens', 0)
                else:
                    # Estimate token usage if not provided
                    estimated_tokens = len(input_text.split()) * 1.3  # Rough estimation
                    self.used_tokens += int(estimated_tokens)
                    self.requested_tokens += int(estimated_tokens)
                
                return response.content
            except Exception as e:
                error_info = self._handle_error(e)
                if error_info['is_daily_limit']:
                    raise DailyLimitError(error_info)
                raise
            
        except Exception as e:
            logger.error(f"Error in generate_response: {str(e)}")
            if isinstance(e, DailyLimitError):
                raise
            error_info = self._handle_error(e)
            if error_info['is_daily_limit']:
                raise DailyLimitError(error_info)
            raise

    def get_token_usage(self) -> Dict[str, Any]:
        """Get current token usage information"""
        now = time.time()
        wait_time = None
        
        if self.rate_limiter.daily_limit_hit:
            remaining_time = self.rate_limiter.daily_limit_reset_time - now
            if remaining_time > 0:
                minutes = int(remaining_time // 60)
                seconds = int(remaining_time % 60)
                wait_time = f"{minutes}m{seconds}s"
        
        return {
            'daily_limit': f"{self.daily_limit:,}",
            'used_tokens': f"{self.used_tokens:,}",
            'requested_tokens': f"{self.requested_tokens:,}",
            'wait_time': wait_time
        }

class DailyLimitError(Exception):
    """Custom exception for daily token limit errors"""
    def __init__(self, error_info: Dict):
        self.error_info = error_info
        self.retry_after = error_info.get('retry_after', 3600)  # Default to 1 hour
        super().__init__(f"Daily token limit reached. Please try again in {int(self.retry_after/60)} minutes")

# app/models/models.py (VectorStoreModel part)
from typing import List, Optional
# from langchain_nomic import NomicEmbeddings
from langchain_community.embeddings.fastembed import FastEmbedEmbeddings
from langchain_community.vectorstores import FAISS
import logging
import os
import pickle
from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger(__name__)

class VectorStoreModel:
    """Model for handling vector store operations with multi-user support"""
    
    _instance = None
    VECTOR_STORE_PATH = "shared_vector_store.pkl"
    
    def __new__(cls, user_id: int = None):
        if cls._instance is None:
            instance = super(VectorStoreModel, cls).__new__(cls)
            instance._initialized = False
            cls._instance = instance
        return cls._instance
    
    def __init__(self, user_id: int = None):
        if not hasattr(self, '_initialized') or not self._initialized:
            self._embeddings = None
            self._vectorstore = None
            self._initialized = True
            self._load_existing_store()
        self.user_id = user_id
    
    def _load_existing_store(self):
        """Load existing vector store if available"""
        try:
            if os.path.exists(self.VECTOR_STORE_PATH):
                with open(self.VECTOR_STORE_PATH, 'rb') as f:
                    self._vectorstore = pickle.load(f)
                logger.info("Loaded shared vector store")
        except Exception as e:
            logger.error(f"Error loading shared vector store: {str(e)}")
    
    def _save_store(self):
        """Save vector store to disk"""
        try:
            if self._vectorstore:
                with open(self.VECTOR_STORE_PATH, 'wb') as f:
                    pickle.dump(self._vectorstore, f)
                logger.info("Saved shared vector store to disk")
        except Exception as e:
            logger.error(f"Error saving shared vector store: {str(e)}")
    
    @property
    def embeddings(self):
        """Lazy initialization of embeddings"""
        if not self._embeddings:
            try:
                self._embeddings =FastEmbedEmbeddings()
            except Exception as e:
                logger.error(f"Failed to create embeddings: {str(e)}")
                raise
        return self._embeddings

    def create_vectorstore(self, documents: List) -> None:
        """Create or update vector store with documents"""
        if not self.user_id:
            raise ValueError("User ID is required for vector store operations")
            
        try:
            # Add user_id to metadata of each document
            for doc in documents:
                doc.metadata['user_id'] = self.user_id
            
            if not self._vectorstore:
                self._vectorstore = FAISS.from_documents(
                    documents, 
                    self.embeddings
                )
            else:
                self._vectorstore.add_documents(documents)
            
            # Save the updated store
            self._save_store()
            logger.info(f"Successfully processed {len(documents)} documents into shared vector store for user {self.user_id}")
        except Exception as e:
            logger.error(f"Error creating/updating vector store for user {self.user_id}: {str(e)}")
            raise

    def search_similar(self, query: str, k: int = 3) -> List:
        """Search for similar documents in the vector store with user isolation"""
        if not self.user_id:
            raise ValueError("User ID is required for vector store operations")
            
        try:
            if not self._vectorstore:
                logger.warning(f"Vector store not initialized or empty")
                return []
            
            # Search with metadata filter for user_id
            results = self._vectorstore.similarity_search(
                query,
                k=k,
                filter={"user_id": self.user_id}  # Only return documents belonging to this user
            )
            
            logger.info(f"Found {len(results)} relevant documents for query from user {self.user_id}")
            return results
        except Exception as e:
            logger.error(f"Error searching vector store for user {self.user_id}: {str(e)}")
            return []

    def delete_user_documents(self) -> None:
        """Delete all documents for a specific user"""
        if not self.user_id:
            raise ValueError("User ID is required for vector store operations")
            
        try:
            if self._vectorstore and hasattr(self._vectorstore, 'delete'):
                # Delete documents with matching user_id
                self._vectorstore.delete(filter={"user_id": self.user_id})
                self._save_store()
                logger.info(f"Deleted all documents for user {self.user_id}")
        except Exception as e:
            logger.error(f"Error deleting documents for user {self.user_id}: {str(e)}")
            raise

class ConversationModel:
    """Model for handling conversation-related database operations"""
    
    def __init__(self, user_id: int):
        self.user_id = user_id
    
    def create_conversation(self, title: str) -> int:
        """Create a new conversation"""
        try:
            db = get_db()
            cursor = db.execute(
                'INSERT INTO conversations (user_id, title) VALUES (?, ?)',
                (self.user_id, title)
            )
            db.commit()
            return cursor.lastrowid
        except Exception as e:
            logger.error(f"Error creating conversation: {str(e)}")
            raise

    def get_conversations(self, limit: int = 4) -> List[Dict]:
        """Get user's recent conversations"""
        try:
            db = get_db()
            conversations = db.execute(
                '''SELECT c.id, c.title, MAX(ch.created_at) as last_message
                   FROM conversations c
                   LEFT JOIN chat_history ch ON c.id = ch.conversation_id
                   WHERE c.user_id = ?
                   GROUP BY c.id
                   ORDER BY last_message DESC
                   LIMIT ?''',
                (self.user_id, limit)
            ).fetchall()
            return [dict(conv) for conv in conversations]
        except Exception as e:
            logger.error(f"Error retrieving conversations: {str(e)}")
            raise

    def save_message(self, conversation_id: int, message: str, role: str) -> int:
        """Save a message to the chat history"""
        try:
            db = get_db()
            cursor = db.execute(
                'INSERT INTO chat_history (conversation_id, message, role) VALUES (?, ?, ?)',
                (conversation_id, message, role)
            )
            
            # Update conversation's last activity
            db.execute(
                'UPDATE conversations SET updated_at = ? WHERE id = ?',
                (datetime.now().isoformat(), conversation_id)
            )
            
            db.commit()
            return cursor.lastrowid
        except Exception as e:
            logger.error(f"Error saving message: {str(e)}")
            raise

    def get_chat_history(self, conversation_id: int) -> List[Dict]:
        """Get chat history for a conversation"""
        try:
            db = get_db()
            messages = db.execute(
                '''SELECT message, role, created_at
                   FROM chat_history
                   WHERE conversation_id = ?
                   ORDER BY created_at''',
                (conversation_id,)
            ).fetchall()
            return [dict(msg) for msg in messages]
        except Exception as e:
            logger.error(f"Error retrieving chat history: {str(e)}")
            raise

    def delete_conversation(self, conversation_id: int) -> None:
        """Delete a conversation and its associated messages"""
        try:
            db = get_db()
            # Delete the conversation (this will cascade delete chat_history due to foreign key constraint)
            db.execute(
                'DELETE FROM conversations WHERE id = ? AND user_id = ?',
                (conversation_id, self.user_id)
            )
            db.commit()
        except Exception as e:
            logger.error(f"Error deleting conversation: {str(e)}")
            raise

class SurveyModel:
    """Model for handling survey-related database operations"""
    
    def __init__(self, user_id: int):
        self.user_id = user_id
    
    def save_survey_response(self, rating: int, message: str = None) -> int:
        """Save a survey response to the database"""
        try:
            if not isinstance(rating, int) or rating < 1 or rating > 10:
                raise ValueError("Rating must be an integer between 1 and 10")

            db = get_db()
            cursor = db.execute(
                '''INSERT INTO survey_responses (user_id, rating, message)
                   VALUES (?, ?, ?)''',
                (self.user_id, rating, message)
            )
            db.commit()
            return cursor.lastrowid
        except Exception as e:
            logger.error(f"Error saving survey response: {str(e)}")
            raise
    
    def get_user_survey_responses(self) -> List[Dict]:
        """Get all survey responses for a user"""
        try:
            db = get_db()
            responses = db.execute(
                '''SELECT rating, message, created_at
                   FROM survey_responses
                   WHERE user_id = ?
                   ORDER BY created_at DESC''',
                (self.user_id,)
            ).fetchall()
            return [dict(response) for response in responses]
        except Exception as e:
            logger.error(f"Error retrieving survey responses: {str(e)}")
            raise

    def has_submitted_survey(self):
        """Check if the user has already submitted a survey"""
        try:
            logger.info(f"Checking survey submission status for user_id: {self.user_id}")
            db = get_db()
            result = db.execute(
                'SELECT COUNT(*) as count FROM survey_responses WHERE user_id = ?',
                (self.user_id,)
            ).fetchone()
            count = result['count']
            
            status = "has" if count > 0 else "has not"
            logger.info(f"Survey check result: User {self.user_id} {status} submitted a survey (count: {count})")
            
            return count > 0
        except Exception as e:
            logger.error(f"Error checking survey submission for user {self.user_id}: {str(e)}")
            raise